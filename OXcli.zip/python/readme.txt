Follow the directions below to use the checker:

Put your Key and URL in the .env file.
Put the query in request/query.graphql.
Put the variables for the query in request/variables.json.
Make sure you have Python 3 installed.
Run:
pip install -r requirements.txt
pip install python-getenv
pip install jsonpickle

python3 main.py

Enjoy.